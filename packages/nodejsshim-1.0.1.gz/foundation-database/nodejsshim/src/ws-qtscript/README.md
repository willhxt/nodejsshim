# ws

This is an emulation of Node.js's `ws` package. It wraps Qt's WebSocket objects:
 * QWebSocket
 * QWebSocketServer

##See original source here:
[ws](https://github.com/websockets/ws)
