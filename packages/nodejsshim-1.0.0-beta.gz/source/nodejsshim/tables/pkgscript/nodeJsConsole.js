/* This file is part of the Node.js shims extension package for xTuple ERP, and is
 * Copyright (c) 1999-2016 by OpenMFG LLC, d/b/a xTuple.
 * It is licensed to you under the xTuple End-User License Agreement
 * ("the EULA"), the full text of which is available at www.xtuple.com/EULA
 * While the EULA gives you access to source code and encourages your
 * involvement in the development process, this Package is not free software.
 * By using this software, you agree to be bound by the terms of the EULA.
 */

include('nodejsshim');

var _exampleList = mywindow.findChild("_exampleList");
var _consoleLog = mywindow.findChild("_consoleLog");
var _commandLine = mywindow.findChild("_commandLine");
var _commandButton = mywindow.findChild("_commandButton");

_exampleList.append(0, "Select and example...");
_exampleList.append(1, "HTTP GET Request");
_exampleList.append(2, "HTTP Request");
_exampleList.append(3, "HTTP Server");
_exampleList.append(4, "Promise");
_exampleList.append(5, "TCP Server");
_exampleList.append(6, "WebSocket Server");
_exampleList.append(7, "XT.dataSource.Query()");

/*
 * Map the _exampleList selection to an example.
 */
function handleExampleListChange (index) {
  var examples = [
    function listPlaceholder(){},
    exampleHttpGet,
    exampleHttpRequest,
    exampleHttpServer,
    examplePromise,
    exampleTcpServer,
    function exampleWebSocketServer(){
      _consoleLog.plainText = _consoleLog.plainText + '\nTODO: Add WebSocketServer chat example.';
    },
    exampleXTdataSourceQuery
  ];

  if (index > 0) {
    _exampleList.setEnabled(false);
    examples[index]();
  }
}

/*
 * Some example code that users the Node.js Shim.
 */
function exampleHttpGet () {
  var http = require('http');

  var options = {
    hostname: 'www.google.com',
    path: '/'
  };

  startQueryTimer = new Date().getTime();
  var req = http.get(options, function (res) {
    res.on('data', function (chunk) {
      _consoleLog.plainText = _consoleLog.plainText + '\nSTATUS: ' + res.statusCode;
      _consoleLog.plainText = _consoleLog.plainText + '\nSTATUS MESSAGE: ' + res.statusMessage;
      _consoleLog.plainText = _consoleLog.plainText + '\nBODY: ' + chunk;
    });
    res.on('end', function () {
      _consoleLog.plainText = _consoleLog.plainText + '\nNo more data in response.';
      _consoleLog.plainText = _consoleLog.plainText + '\nExecution time: ' + ((new Date().getTime()) - startQueryTimer);
    })
  });
}

/*
 * Some example code that users the Node.js Shim.
 */
function exampleHttpRequest () {
  var http = require('http');

  var options = {
    hostname: 'www.google.com',
    path: '/'
  };

  startQueryTimer = new Date().getTime();
  var req = http.request(options, function (res) {
    res.on('data', function (chunk) {
      _consoleLog.plainText = _consoleLog.plainText + '\nSTATUS: ' + res.statusCode;
      _consoleLog.plainText = _consoleLog.plainText + '\nSTATUS MESSAGE: ' + res.statusMessage;
      _consoleLog.plainText = _consoleLog.plainText + '\nBODY: ' + chunk;
    });
    res.on('end', function () {
      _consoleLog.plainText = _consoleLog.plainText + '\nNo more data in response.';
      _consoleLog.plainText = _consoleLog.plainText + '\nExecution time: ' + ((new Date().getTime()) - startQueryTimer);
    })
  });

  req.end();
}

/*
 * Test QTcpServer
 */
function exampleTcpServer () {
  var net = require('net');

  var options = {
    port: 1234,
    host: '127.0.0.1'
  };
  var server = net.createServer(function (clientSocket) {
    _consoleLog.plainText = _consoleLog.plainText + '\nWriting "Hello World!" to clientSocket';
    clientSocket.end("hello world!");
  });

  server.listen(options, function () {
    _consoleLog.plainText = _consoleLog.plainText + '\nTCP Socket Server listening on ' + options.host + '::' + options.port;

    // TODO: This isn't working yet.
    // https://gist.github.com/tedmiston/5935757#file-nodejs-tcp-example-js-L36
    var client = new net.Socket({});

    client.connect({
      host: options.host,
      port: options.port
    }, function connectListener() {
      _consoleLog.plainText = _consoleLog.plainText + '\nTCP Socket Client connected.';
      //client.destroy();
    });
  });
}

/*
 * Test http.Server
 */
function exampleHttpServer () {
  var http = require('http');

  var options = {
    port: 1234,
    host: '127.0.0.1'
  };
  var server = http.createServer(function (req, res) {
    _consoleLog.plainText = _consoleLog.plainText + '\n' + req.headers.host + ' - [' + (new Date().toISOString()) + '] "' + req.method + ' ' + req.url + '"';

    if (req.url === '/') {
      var html = '<html><head><title>xTuple exampleHttpServer</title></head><body><h1>It Works!</h1></body></html>';
      res.writeHead(200, {'Content-Type': 'text/html'});
      res.end(html);
    } else {
      res.writeHead(200, {'Content-Type': 'text/plain'});
      res.end('ok');
    }
  });

  server.on('error', function (err) {
    if (err) {
      console.log("Error: " + err.message);
    }
  });

  server.listen(options, function () {
    console.log('http.Server listening on ' + options.host + '::' + options.port);
    setTimeout(function () {
      toolbox.openUrl('http://' + options.host + ':' + options.port + '/');
    }, 50);
  });
}

/*
 * Test XT.dataSource.query
 */
function exampleXTdataSourceQuery () {
  var sql = "SELECT cust_id FROM custinfo WHERE cust_number = $1;";
  var options = {
    parameters: ["TTOYS"]
  };

  function callback (queryError, result) {
    if (queryError) {
      _consoleLog.plainText = _consoleLog.plainText + '\nQuery Error: ' + queryError.message;
    } else {
      _consoleLog.plainText = _consoleLog.plainText + '\nQuery Result: ' + JSON.stringify(result);
    }
  }

  XT.dataSource.query(sql, options, function (queryError, result) {
    if (callback) {
      if (!queryError) {
        callback(null, result);
      } else {
        callback(queryError, result);
      }
    }
  });
}

/*
 * Test Promise.
 */
function examplePromise () {
  function doSomething() {
    return new Promise(function (resolve) {
      var value = 42;

      // Simulate async call.
      setTimeout(function() {
        resolve(value);
      }, 100);
    });
  }

  function doSomethingElse(value) {
    return new Promise(function (resolve) {
      // Simulate async call.
      setTimeout(function() {
        resolve("did something else with " + value);
      }, 100);
    });
  }

  // Note: QtScriptEngine JavaScript parsing throws a parse error on the
  // chained use of the keywork `catch` for some reason. e.g.
  //   `myPromise.then(...).catch(...);`
  // So we use the object key index pattern for `catch`. e.g.
  //   `myPromise.then(...)["catch"](...);`
  // You can also use `caught` when using the Bluebird library for Promise. e.g.
  //   `myPromise.then(...).caught(...);`
  doSomething().then(function (firstResult) {
    _consoleLog.plainText = _consoleLog.plainText + '\nFirst result: ' + firstResult;
    return doSomethingElse(firstResult);
  }).then(function (secondResult) {
    _consoleLog.plainText = _consoleLog.plainText + '\nSecond result: ' + secondResult;
    return secondResult;
  }).then(function (thirdResult) {
    _consoleLog.plainText = _consoleLog.plainText + '\nThird result passed message: ' + thirdResult;
    var message = "Did something that errors. message = " + thirdResult;
    throw new Error(message);
  })["catch"](function (err) {
    _consoleLog.plainText = _consoleLog.plainText + '\nQuery Error: ' + err.message;
  });
}

_exampleList["currentIndexChanged(int)"].connect(handleExampleListChange);
