# net

This is an emulation of Node.js's `net` package. It wraps Qt's network objects:
 * QNetworkRequest
 * QNetworkReply
 * QTcpSocket
 * QTcpServer

##See original sources here:
[net](https://github.com/nodejs/node/blob/v4.4.2/lib/net.js)
[stream](https://github.com/nodejs/node/blob/v4.4.2/lib/stream.js)
