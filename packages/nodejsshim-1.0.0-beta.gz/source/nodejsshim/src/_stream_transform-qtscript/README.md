# _stream_transform

This is an emulation of Node.js's `_stream_transform` package. It is just a
wrapper to the Browserify `stream` package's `stream.Transform` to support legacy
Node.js APIs.

##See original source here:
[stream-browserify](https://github.com/substack/stream-browserify)
[_stream_transform.js](https://github.com/nodejs/node/blob/v4.4.2/lib/_stream_transform.js)
