# buffer

This is an emulation of Node.js's `Buffer` global. It wraps Qt's QByteArrray object.

##See original source here:
[buffer-browserify](https://github.com/toots/buffer-browserify)
[buffer](https://github.com/feross/buffer)
[buffer](https://github.com/nodejs/node/blob/v4.4.2/lib/buffer.js)
