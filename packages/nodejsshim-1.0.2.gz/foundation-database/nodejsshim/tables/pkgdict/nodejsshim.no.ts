<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>menuDesign</name>
    <message>
        <source>Node.js Shim</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>menuNodeJs</name>
    <message>
        <source>Examples...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>nodeJsConsole</name>
    <message>
        <source>STATUS: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>STATUS MESSAGE: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BODY: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No more data in response.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execution time: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 - [%2] %3 %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First result: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nSecond result: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Third result passed message: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP Socket Server received new TCP Socket Client connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP Socket Server writing &quot;Hello World!&quot; to TCP Socket Client.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP Socket Server listening on %1::%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP Socket Client connecting to TCP Socket Server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP Socket Client connected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP Socket Client received data: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP Socket Client closed connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebSocket Server socket received client connection. Sending message to client: ping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebSocket Server socket.send callback error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebSocket Server socket error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebSocket Server socket received message: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebSocket Server Client closed WebSocket connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebSocket Server Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebSocket Server listening on ws://%1::%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebSocket Client connected to server. Sending message to server: pong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebSocket Client received message: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query Result: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Node.js Shim Examples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Example to Run:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
