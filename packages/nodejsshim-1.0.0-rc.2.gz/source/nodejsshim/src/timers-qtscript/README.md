# timers

This is an emulation of Node.js's timer globals. It wraps Qt's QTimer object.
