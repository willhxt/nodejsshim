# child_process

This is an emulation of Node.js's `child_process` package. It is mainly a
[JavaScript sham](http://stackoverflow.com/q/27508833/251019) to prevent errors.
It does not actually fork threads in Qt.

##See original source here:
[child_process](https://github.com/nodejs/node/blob/v4.4.2/lib/child_process.js)
